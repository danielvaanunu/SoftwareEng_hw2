public enum SortingField {
    /**
     * setting a const for each sort
     */
    NAME,
    SIZE,
    DATE,
}
